#include "app.cpp"

int main(){
    runningApp();
    return 0;
}